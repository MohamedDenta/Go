package main

import (
	"net/url"

	"./screens"

	"./data"

	"fyne.io/fyne"
	"fyne.io/fyne/canvas"
	"fyne.io/fyne/layout"
	"fyne.io/fyne/theme"
	"fyne.io/fyne/widget"
)

var app = screens.App
var w = screens.Wind

func main() {

	app.Settings().SetTheme(theme.LightTheme())
	entry := widget.NewEntry()
	entry.SetText("Path")
	//lbl := widget.NewLabel("Hello Fyne!")

	w.SetContent(screens.WelcomeScreen())
	//w.SetContent(vbox)
	w.CenterOnScreen()
	//w.SetFullScreen(true)
	w.Resize(fyne.NewSize(300, 300))
	w.ShowAndRun()
}

func welcomeScreen() fyne.CanvasObject {
	logo := canvas.NewImageFromResource(data.FyneScene)
	logo.SetMinSize(fyne.NewSize(228, 167))

	link, err := url.Parse("https://www.inovatian.com/")
	if err != nil {
		fyne.LogError("Could not parse URL", err)
	}

	return widget.NewVBox(
		widget.NewLabelWithStyle("Welcome to Inovatian App", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		layout.NewSpacer(),
		widget.NewHBox(layout.NewSpacer(), logo, layout.NewSpacer()),
		widget.NewHyperlinkWithStyle("inovatian", link, fyne.TextAlignCenter, fyne.TextStyle{}),
		layout.NewSpacer(),

		widget.NewGroup("",
			fyne.NewContainerWithLayout(layout.NewGridLayout(2),
				widget.NewButton("Next", func() {
					// a.Settings().SetTheme(theme.DarkTheme())
					// set content
					w.SetContent(screens.BuildContent())
				}),
				widget.NewButton("Cancel", func() {
					// a.Settings().SetTheme(theme.LightTheme())
					app.Quit()
				}),
			),
		),
	)
}

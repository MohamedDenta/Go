package screens

import (
	"net/url"
	"newinstall/guiproj/data"
	"newinstall/guiproj/utils"

	"fyne.io/fyne"
	"fyne.io/fyne/canvas"
	"fyne.io/fyne/layout"
	"fyne.io/fyne/widget"
)

var execstartpath string = "/bin/inostorage"
var autoservice string = `[Unit]
Description=Sleep service
ConditionPathExists=` + execstartpath + `
After=network.target
[Service]
Type=simple
Restart=on-failure
RestartSec=30
startLimitIntervalSec=60
# WorkingDirectory=/home/moha/go/src/service-demo
ExecStart=` + execstartpath + ` --name=demo-service
# # make sure log directory exists and owned by syslog
# PermissionsStartOnly=true
# ExecStartPre=/bin/mkdir -p /var/log/sleepservice
# ExecStartPre=/bin/chown syslog:adm /var/log/sleepservice
# ExecStartPre=/bin/chmod 755 /var/log/sleepservice
# StandardOutput=syslog
# StandardError=syslog
# SyslogIdentifier=sleepservice
 
[Install]
WantedBy=multi-user.target`

func ServiceScreen() fyne.CanvasObject {
	logo := canvas.NewImageFromResource(data.FyneScene)
	logo.SetMinSize(fyne.NewSize(228, 167))

	link, err := url.Parse("https://www.inovatian.com/")
	if err != nil {
		fyne.LogError("Could not parse URL", err)
	}

	return widget.NewVBox(
		widget.NewLabelWithStyle("Welcome to Inovatian App", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		layout.NewSpacer(),
		widget.NewHBox(layout.NewSpacer(), logo, layout.NewSpacer()),
		widget.NewHyperlinkWithStyle("inovatian", link, fyne.TextAlignCenter, fyne.TextStyle{}),
		layout.NewSpacer(),

		widget.NewGroup("",
			fyne.NewContainerWithLayout(layout.NewGridLayout(2),

				widget.NewButton("Cancel", func() {
					// a.Settings().SetTheme(theme.LightTheme())
					App.Quit()
				}),
				widget.NewButton("Finish", func() {
					// a.Settings().SetTheme(theme.DarkTheme())
					// set content
					utils.WriteService(&autoservice)
					App.Quit()
				}),
			),
		),
	)
}

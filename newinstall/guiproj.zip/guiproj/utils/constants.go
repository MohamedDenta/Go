package utils

var (
	Defaultpath = ""
	Configpath  = "/etc"
	Buildpath   = "/bin"
	Buildpath2  = "/usr/bin"
)
